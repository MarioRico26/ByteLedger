import { prisma } from "@/lib/prisma"
import { DEFAULT_ORG_ID } from "@/lib/tenant"
import EstimatesClient from "./ui/EstimatesClient"

export const dynamic = "force-dynamic"

export default async function EstimatesPage() {
  const rows = await prisma.estimate.findMany({
    where: { organizationId: DEFAULT_ORG_ID },
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      customer: { select: { id: true, fullName: true, email: true, phone: true, homeAddress: true, workAddress: true } },
      items: { select: { id: true } },
    },
  })

  const initialEstimates = rows.map((e) => ({
    id: e.id,
    title: e.title,
    status: e.status,
    createdAt: e.createdAt.toISOString(),
    totalAmount: Number(e.totalAmount),
    subtotalAmount: Number(e.subtotalAmount),
    taxRate: Number(e.taxRate),
    taxAmount: Number(e.taxAmount),
    discountAmount: Number(e.discountAmount),
    saleId: e.saleId,
    customer: e.customer,
    itemsCount: e.items.length,
  }))

  return <EstimatesClient initialEstimates={initialEstimates as any} />
}
