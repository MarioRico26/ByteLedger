import { prisma } from "@/lib/prisma"
import { DEFAULT_ORG_ID } from "@/lib/tenant"
import NewEstimateForm from "@/app/estimates/new/ui/NewEstimateForm"

export default async function EditEstimatePage(props: { params: Promise<{ id: string }> }) {
  const { id } = await props.params

  const estimate = await prisma.estimate.findFirst({
    where: { id, organizationId: DEFAULT_ORG_ID },
    include: {
      items: { orderBy: { createdAt: "asc" } },
    },
  })

  if (!estimate) {
    return (
      <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-5 text-sm text-zinc-400">
        Estimate not found.
      </div>
    )
  }

  const initialEstimate = {
    id: estimate.id,
    title: estimate.title,
    customerId: estimate.customerId,
    notes: estimate.notes,
    taxRate: Number(estimate.taxRate),
    discountAmount: Number(estimate.discountAmount),
    saleId: estimate.saleId,
    items: estimate.items.map((it) => ({
      id: it.id,
      productId: it.productId,
      name: it.name,
      type: it.type,
      quantity: Number(it.quantity),
      unitPrice: Number(it.unitPrice),
    })),
  }

  return <NewEstimateForm mode="edit" estimateId={id} initialEstimate={initialEstimate} />
}
