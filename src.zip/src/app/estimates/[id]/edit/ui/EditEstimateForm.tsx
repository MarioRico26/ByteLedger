"use client"

import { useEffect, useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import type { ProductType } from "@prisma/client"

type CustomerOption = {
  id: string
  fullName: string
  email: string | null
  phone: string | null
}

type ProductOption = {
  id: string
  name: string
  type: "PRODUCT" | "SERVICE"
  price: string | number | null
  active?: boolean
}

type EditItem = {
  productId: string | null
  name: string
  type: "PRODUCT" | "SERVICE"
  quantity: number
  unitPrice: number
}

function asNumber(v: unknown, fallback = 0) {
  const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : NaN
  return Number.isFinite(n) ? n : fallback
}

export default function EditEstimateForm({ estimateId }: { estimateId: string }) {
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [customers, setCustomers] = useState<CustomerOption[]>([])
  const [products, setProducts] = useState<ProductOption[]>([])

  const [title, setTitle] = useState("")
  const [customerId, setCustomerId] = useState<string>("")
  const [taxRate, setTaxRate] = useState<number>(0)
  const [discountAmount, setDiscountAmount] = useState<number>(0)
  const [notes, setNotes] = useState<string>("")
  const [items, setItems] = useState<EditItem[]>([])

  useEffect(() => {
    let alive = true
    async function load() {
      try {
        setLoading(true)
        setError(null)

        const [estRes, custRes, prodRes] = await Promise.all([
          fetch(`/api/estimates/${estimateId}`),
          fetch(`/api/customers`),
          fetch(`/api/products`),
        ])

        if (!estRes.ok) throw new Error("Failed to load estimate")
        if (!custRes.ok) throw new Error("Failed to load customers")
        if (!prodRes.ok) throw new Error("Failed to load products")

        const est = await estRes.json()
        const cust = await custRes.json()
        const prod = await prodRes.json()

        if (!alive) return

        setCustomers(cust?.customers ?? cust ?? [])
        setProducts(prod?.products ?? prod ?? [])

        setTitle(est.title ?? "")
        setCustomerId(est.customerId ?? "")
        setTaxRate(asNumber(est.taxRate, 0))
        setDiscountAmount(asNumber(est.discountAmount, 0))
        setNotes(est.notes ?? "")

        const loadedItems: EditItem[] = (est.items ?? []).map((it: any) => ({
          productId: it.productId ?? null,
          name: it.name ?? "",
          type: (it.type as ProductType) === "SERVICE" ? "SERVICE" : "PRODUCT",
          quantity: asNumber(it.quantity, 1),
          unitPrice: asNumber(it.unitPrice, 0),
        }))

        setItems(loadedItems.length ? loadedItems : [{ productId: null, name: "", type: "SERVICE", quantity: 1, unitPrice: 0 }])
      } catch (e: any) {
        if (!alive) return
        setError(e?.message ?? "Something went wrong")
      } finally {
        if (alive) setLoading(false)
      }
    }
    load()
    return () => {
      alive = false
    }
  }, [estimateId])

  const subtotal = useMemo(() => {
    return items.reduce((sum, it) => sum + Math.max(0, asNumber(it.quantity, 0) * asNumber(it.unitPrice, 0)), 0)
  }, [items])

  const taxAmount = useMemo(() => {
    const r = Math.max(0, asNumber(taxRate, 0))
    return r > 0 ? subtotal * (r / 100) : 0
  }, [subtotal, taxRate])

  const total = useMemo(() => {
    const disc = Math.max(0, asNumber(discountAmount, 0))
    return Math.max(subtotal + taxAmount - disc, 0)
  }, [subtotal, taxAmount, discountAmount])

  function updateItem(idx: number, patch: Partial<EditItem>) {
    setItems((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)))
  }

  function addCustom(type: "PRODUCT" | "SERVICE") {
    setItems((prev) => [...prev, { productId: null, name: "", type, quantity: 1, unitPrice: 0 }])
  }

  function removeItem(idx: number) {
    setItems((prev) => prev.filter((_, i) => i !== idx))
  }

  async function onSave() {
    setSaving(true)
    setError(null)
    try {
      const cleaned = items
        .map((it) => ({
          productId: it.productId,
          name: String(it.name ?? "").trim(),
          type: it.type,
          quantity: Math.max(0, asNumber(it.quantity, 0)),
          unitPrice: Math.max(0, asNumber(it.unitPrice, 0)),
        }))
        .filter((it) => it.name && it.quantity > 0)

      if (!title.trim()) throw new Error("Title is required")
      if (!customerId) throw new Error("Customer is required")
      if (cleaned.length === 0) throw new Error("Add at least one line item")

      const res = await fetch(`/api/estimates/${estimateId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          customerId,
          notes: notes?.trim() ? notes : null,
          taxRate: Math.max(0, asNumber(taxRate, 0)),
          discountAmount: Math.max(0, asNumber(discountAmount, 0)),
          items: cleaned,
        }),
      })

      if (!res.ok) {
        const msg = await res.text().catch(() => "")
        throw new Error(msg || "Failed to save")
      }

      router.push(`/estimates/${estimateId}`)
      router.refresh()
    } catch (e: any) {
      setError(e?.message ?? "Failed")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-5 text-sm text-zinc-400">
        Loading estimate...
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Edit Estimate</h1>
          <p className="mt-1 text-sm text-zinc-400">Update items, tax, discount, and customer.</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => router.back()}
            className="rounded-xl border border-zinc-800 bg-zinc-950/40 px-3 py-2 text-sm font-medium text-zinc-100 hover:bg-zinc-900/40"
          >
            Back
          </button>
          <button
            onClick={onSave}
            disabled={saving}
            className="rounded-xl bg-white px-3 py-2 text-sm font-semibold text-black hover:bg-zinc-200 disabled:opacity-60"
          >
            {saving ? "Saving..." : "Save"}
          </button>
        </div>
      </div>

      {error ? (
        <div className="rounded-2xl border border-red-900/50 bg-red-950/30 p-4 text-sm text-red-200">
          {error}
        </div>
      ) : null}

      <div className="grid gap-4 md:grid-cols-3">
        <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-4 md:col-span-2">
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label className="text-xs text-zinc-400">Title</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                placeholder="Estimate title"
              />
            </div>
            <div>
              <label className="text-xs text-zinc-400">Customer</label>
              <select
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
              >
                <option value="">Select...</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.fullName}
                    {c.email ? ` • ${c.email}` : ""}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-3">
            <div>
              <label className="text-xs text-zinc-400">Tax rate (%)</label>
              <input
                value={taxRate}
                onChange={(e) => setTaxRate(asNumber(e.target.value, 0))}
                className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                inputMode="decimal"
              />
            </div>
            <div>
              <label className="text-xs text-zinc-400">Discount ($)</label>
              <input
                value={discountAmount}
                onChange={(e) => setDiscountAmount(asNumber(e.target.value, 0))}
                className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                inputMode="decimal"
              />
            </div>
            <div>
              <label className="text-xs text-zinc-400">Notes (optional)</label>
              <input
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                placeholder="..."
              />
            </div>
          </div>

          <div className="mt-5">
            <div className="mb-2 flex items-center justify-between">
              <div className="text-sm font-semibold">Line items</div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => addCustom("SERVICE")}
                  className="rounded-xl border border-zinc-800 bg-zinc-950/40 px-3 py-2 text-xs font-medium text-zinc-100 hover:bg-zinc-900/40"
                >
                  + Service
                </button>
                <button
                  type="button"
                  onClick={() => addCustom("PRODUCT")}
                  className="rounded-xl border border-zinc-800 bg-zinc-950/40 px-3 py-2 text-xs font-medium text-zinc-100 hover:bg-zinc-900/40"
                >
                  + Product
                </button>
              </div>
            </div>

            <div className="space-y-3">
              {items.map((it, idx) => (
                <div
                  key={idx}
                  className="rounded-2xl border border-zinc-800 bg-zinc-950/30 p-3"
                >
                  <div className="grid gap-3 md:grid-cols-12 md:items-end">
                    <div className="md:col-span-4">
                      <label className="text-xs text-zinc-400">Catalog item (optional)</label>
                      <select
                        value={it.productId ?? ""}
                        onChange={(e) => {
                          const id = e.target.value || null
                          if (!id) {
                            updateItem(idx, { productId: null })
                            return
                          }
                          const p = products.find((x) => x.id === id)
                          if (p) {
                            updateItem(idx, {
                              productId: p.id,
                              name: p.name,
                              type: p.type,
                              unitPrice: asNumber(p.price, 0),
                            })
                          } else {
                            updateItem(idx, { productId: id })
                          }
                        }}
                        className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                      >
                        <option value="">Custom line...</option>
                        {products
                          .filter((p) => p.active !== false)
                          .map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} • {p.type} • ${asNumber(p.price, 0).toFixed(2)}
                            </option>
                          ))}
                      </select>
                    </div>

                    <div className="md:col-span-4">
                      <label className="text-xs text-zinc-400">Name</label>
                      <input
                        value={it.name}
                        onChange={(e) => updateItem(idx, { name: e.target.value })}
                        className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                        placeholder="Line item name"
                      />
                    </div>

                    <div className="md:col-span-1">
                      <label className="text-xs text-zinc-400">Type</label>
                      <select
                        value={it.type}
                        onChange={(e) => updateItem(idx, { type: e.target.value as any })}
                        className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                      >
                        <option value="SERVICE">SERVICE</option>
                        <option value="PRODUCT">PRODUCT</option>
                      </select>
                    </div>

                    <div className="md:col-span-1">
                      <label className="text-xs text-zinc-400">Qty</label>
                      <input
                        value={it.quantity}
                        onChange={(e) => updateItem(idx, { quantity: asNumber(e.target.value, 1) })}
                        className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                        inputMode="numeric"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="text-xs text-zinc-400">Unit price</label>
                      <input
                        value={it.unitPrice}
                        onChange={(e) => updateItem(idx, { unitPrice: asNumber(e.target.value, 0) })}
                        className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
                        inputMode="decimal"
                      />
                    </div>

                    <div className="md:col-span-12 flex items-center justify-between">
                      <div className="text-xs text-zinc-500">
                        Line total: <span className="text-zinc-200">${(Math.max(0, it.quantity) * Math.max(0, it.unitPrice)).toFixed(2)}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeItem(idx)}
                        className="rounded-xl border border-zinc-800 bg-zinc-950/40 px-3 py-2 text-xs font-medium text-zinc-100 hover:bg-zinc-900/40"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-4">
          <div className="text-sm font-semibold">Summary</div>
          <div className="mt-3 space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-zinc-400">Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-zinc-400">Tax</span>
              <span>${taxAmount.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-zinc-400">Discount</span>
              <span>-${Math.max(0, discountAmount).toFixed(2)}</span>
            </div>
            <div className="h-px bg-zinc-800" />
            <div className="flex items-center justify-between text-base font-semibold">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
