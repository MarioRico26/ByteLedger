import Link from "next/link"
import { prisma } from "@/lib/prisma"
import { DEFAULT_ORG_ID } from "@/lib/tenant"
import EstimateActions from "./EstimateActions"

export const dynamic = "force-dynamic"

function money(n: any) {
  const v = typeof n === "string" ? Number(n) : typeof n === "number" ? n : Number(n || 0)
  return (Number.isFinite(v) ? v : 0).toFixed(2)
}

export default async function EstimateDetailPage(props: { params: Promise<{ id: string }> }) {
  const { id } = await props.params

  const estimate = await prisma.estimate.findFirst({
    where: { id, organizationId: DEFAULT_ORG_ID },
    include: {
      customer: true,
      items: { orderBy: { createdAt: "asc" } },
      sale: { select: { id: true } },
    },
  })

  if (!estimate) {
    return (
      <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-5 text-sm text-zinc-400">
        Estimate not found.
      </div>
    )
  }

  const converted = Boolean(estimate.saleId)

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <div className="text-xs font-semibold tracking-widest text-zinc-500">ESTIMATE</div>
          <h1 className="mt-2 truncate text-2xl font-semibold tracking-tight text-zinc-100">{estimate.title}</h1>
          <div className="mt-1 text-sm text-zinc-400">
            {estimate.customer?.fullName ? (
              <>
                For <span className="text-zinc-200">{estimate.customer.fullName}</span>
              </>
            ) : (
              "Customer not set"
            )}
            <span className="mx-2">•</span>
            Status <span className="text-zinc-200">{estimate.status}</span>
            {converted ? (
              <>
                <span className="mx-2">•</span>
                <span className="text-purple-200">Converted to sale</span>
              </>
            ) : null}
          </div>
        </div>

        <EstimateActions estimateId={estimate.id} saleId={estimate.saleId} />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="md:col-span-2 space-y-4">
          <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-4">
            <div className="text-sm font-semibold text-zinc-100">Items</div>
            <div className="mt-3 overflow-hidden rounded-xl border border-zinc-800">
              <table className="w-full text-left text-sm">
                <thead className="bg-zinc-950/60 text-xs font-semibold text-zinc-400">
                  <tr>
                    <th className="px-3 py-2">Item</th>
                    <th className="px-3 py-2">Type</th>
                    <th className="px-3 py-2 text-right">Qty</th>
                    <th className="px-3 py-2 text-right">Unit</th>
                    <th className="px-3 py-2 text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800">
                  {estimate.items.map((it) => (
                    <tr key={it.id} className="bg-zinc-950/30 text-zinc-200">
                      <td className="px-3 py-2">{it.name}</td>
                      <td className="px-3 py-2 text-zinc-400">{it.type}</td>
                      <td className="px-3 py-2 text-right">{Number(it.quantity)}</td>
                      <td className="px-3 py-2 text-right">${money(it.unitPrice)}</td>
                      <td className="px-3 py-2 text-right font-semibold">${money(it.lineTotal)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {estimate.notes ? (
              <div className="mt-4 rounded-xl border border-zinc-800 bg-zinc-950/30 p-3 text-sm text-zinc-300">
                <div className="text-xs font-semibold text-zinc-400">Notes</div>
                <div className="mt-1 whitespace-pre-wrap">{estimate.notes}</div>
              </div>
            ) : null}
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-4">
            <div className="text-sm font-semibold text-zinc-100">Totals</div>
            <div className="mt-3 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Subtotal</span>
                <span className="text-zinc-100">${money(estimate.subtotalAmount)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Tax ({money(estimate.taxRate)}%)</span>
                <span className="text-zinc-100">${money(estimate.taxAmount)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-zinc-400">Discount</span>
                <span className="text-zinc-100">-${money(estimate.discountAmount)}</span>
              </div>
              <div className="h-px bg-zinc-800" />
              <div className="flex items-center justify-between">
                <span className="font-semibold text-zinc-100">Total</span>
                <span className="text-lg font-semibold text-zinc-100">${money(estimate.totalAmount)}</span>
              </div>
            </div>
          </div>

          {estimate.customer ? (
            <div className="rounded-2xl border border-zinc-800 bg-zinc-950/40 p-4">
              <div className="text-sm font-semibold text-zinc-100">Customer</div>
              <div className="mt-2 text-sm text-zinc-300">{estimate.customer.fullName}</div>
              <div className="mt-1 text-xs text-zinc-500">
                {estimate.customer.email ? <div>{estimate.customer.email}</div> : null}
                {estimate.customer.phone ? <div>{estimate.customer.phone}</div> : null}
                {estimate.customer.workAddress ? <div>{estimate.customer.workAddress}</div> : null}
                {estimate.customer.homeAddress ? <div>{estimate.customer.homeAddress}</div> : null}
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  )
}
