import React from "react"

type Org = {
  name: string
  businessName: string | null
  email: string | null
  phone: string | null
  website: string | null
  addressLine1: string | null
  addressLine2: string | null
  city: string | null
  state: string | null
  zip: string | null
  country: string | null
}

type Customer = {
  fullName: string
  email: string | null
  phone: string | null
  homeAddress: string | null
  workAddress: string | null
}

type Item = {
  id: string
  name: string
  type: "PRODUCT" | "SERVICE"
  quantity: any
  unitPrice: any
  lineTotal: any
}

type Estimate = {
  id: string
  title: string
  createdAt: Date
  status: string
  notes: string | null
  subtotalAmount: any
  taxRate: any
  taxAmount: any
  discountAmount: any
  totalAmount: any
}

function money(v: any) {
  const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : Number(v || 0)
  const safe = Number.isFinite(n) ? n : 0
  return safe.toFixed(2)
}

function lineAddress(o: Org) {
  const parts = [
    o.addressLine1,
    o.addressLine2,
    [o.city, o.state, o.zip].filter(Boolean).join(", ").replace(", ,", ",").trim(),
    o.country,
  ]
    .filter(Boolean)
    .map((x) => String(x).trim())
    .filter(Boolean)

  return parts
}

export default function QuoteDoc(props: {
  estimate: Estimate
  organization: Org
  customer: Customer
  items: Item[]
}) {
  const { estimate, organization: org, customer, items } = props

  const orgName = org.businessName || org.name || "Organization"
  const orgAddress = lineAddress(org)

  const customerAddress = customer.workAddress || customer.homeAddress || ""

  return (
    <div className="bg-white text-black">
      <div className="mx-auto max-w-4xl px-6 py-10">
        {/* Header */}
        <div className="flex flex-col gap-6 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <div className="text-xs font-semibold tracking-widest text-zinc-500">ESTIMATE</div>
            <h1 className="mt-2 text-3xl font-semibold">{estimate.title || "Estimate"}</h1>

            <div className="mt-3 text-sm text-zinc-600">
              <div>
                Estimate ID: <span className="font-medium text-zinc-800">{estimate.id}</span>
              </div>
              <div>
                Date:{" "}
                <span className="font-medium text-zinc-800">
                  {new Date(estimate.createdAt).toLocaleDateString(undefined, {
                    year: "numeric",
                    month: "short",
                    day: "2-digit",
                  })}
                </span>
              </div>
              <div>
                Status: <span className="font-medium text-zinc-800">{estimate.status}</span>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-zinc-50 p-4 text-sm">
            <div className="text-xs font-semibold tracking-widest text-zinc-500">FROM</div>
            <div className="mt-2 text-base font-semibold text-zinc-900">{orgName}</div>

            <div className="mt-2 space-y-1 text-zinc-700">
              {orgAddress.length ? (
                <div className="text-sm">
                  {orgAddress.map((l, idx) => (
                    <div key={idx}>{l}</div>
                  ))}
                </div>
              ) : null}

              {org.email ? <div>{org.email}</div> : null}
              {org.phone ? <div>{org.phone}</div> : null}
              {org.website ? <div>{org.website}</div> : null}
            </div>
          </div>
        </div>

        {/* Bill To */}
        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-zinc-200 bg-white p-4">
            <div className="text-xs font-semibold tracking-widest text-zinc-500">BILL TO</div>
            <div className="mt-2 text-base font-semibold text-zinc-900">{customer.fullName}</div>
            <div className="mt-2 space-y-1 text-sm text-zinc-700">
              {customer.email ? <div>{customer.email}</div> : null}
              {customer.phone ? <div>{customer.phone}</div> : null}
              {customerAddress ? <div className="text-zinc-600">{customerAddress}</div> : null}
            </div>
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-zinc-50 p-4">
            <div className="text-xs font-semibold tracking-widest text-zinc-500">SUMMARY</div>
            <div className="mt-3 space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-zinc-600">Subtotal</span>
                <span className="font-medium">${money(estimate.subtotalAmount)}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-zinc-600">Tax ({money(estimate.taxRate)}%)</span>
                <span className="font-medium">${money(estimate.taxAmount)}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-zinc-600">Discount</span>
                <span className="font-medium">-${money(estimate.discountAmount)}</span>
              </div>

              <div className="h-px bg-zinc-200" />

              <div className="flex items-center justify-between text-base">
                <span className="font-semibold text-zinc-900">Total</span>
                <span className="font-semibold text-zinc-900">${money(estimate.totalAmount)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Items table */}
        <div className="mt-8 overflow-hidden rounded-2xl border border-zinc-200">
          <table className="w-full text-left text-sm">
            <thead className="bg-zinc-50 text-xs font-semibold tracking-widest text-zinc-600">
              <tr>
                <th className="px-4 py-3">ITEM</th>
                <th className="px-4 py-3">TYPE</th>
                <th className="px-4 py-3 text-right">QTY</th>
                <th className="px-4 py-3 text-right">UNIT</th>
                <th className="px-4 py-3 text-right">TOTAL</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-200">
              {items.map((it) => (
                <tr key={it.id} className="bg-white">
                  <td className="px-4 py-3">
                    <div className="font-medium text-zinc-900">{it.name}</div>
                  </td>
                  <td className="px-4 py-3 text-zinc-600">{it.type}</td>
                  <td className="px-4 py-3 text-right text-zinc-700">{Number(it.quantity)}</td>
                  <td className="px-4 py-3 text-right text-zinc-700">${money(it.unitPrice)}</td>
                  <td className="px-4 py-3 text-right font-medium text-zinc-900">${money(it.lineTotal)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Notes */}
        {estimate.notes ? (
          <div className="mt-8 rounded-2xl border border-zinc-200 bg-white p-4">
            <div className="text-xs font-semibold tracking-widest text-zinc-500">NOTES</div>
            <div className="mt-2 whitespace-pre-wrap text-sm text-zinc-700">{estimate.notes}</div>
          </div>
        ) : null}

        {/* Footer */}
        <div className="mt-10 flex flex-col items-center justify-between gap-2 border-t border-zinc-200 pt-6 text-center text-xs text-zinc-500 sm:flex-row sm:text-left">
          <div>
            Powered by <span className="font-semibold text-zinc-700">Byte Networks</span>
          </div>
          <div className="text-zinc-400">Thank you for your business.</div>
        </div>
      </div>
    </div>
  )
}
