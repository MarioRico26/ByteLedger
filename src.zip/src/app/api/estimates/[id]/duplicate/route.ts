import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { DEFAULT_ORG_ID } from "@/lib/tenant"

export async function POST(_: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params

    const estimate = await prisma.estimate.findFirst({
      where: { id, organizationId: DEFAULT_ORG_ID },
      include: { items: { orderBy: { createdAt: "asc" } } },
    })

    if (!estimate) return NextResponse.json({ error: "Estimate not found" }, { status: 404 })

    const created = await prisma.estimate.create({
      data: {
        organizationId: DEFAULT_ORG_ID,
        title: `Copy of ${estimate.title}`,
        customerId: estimate.customerId,
        status: "DRAFT",
        notes: estimate.notes,
        subtotalAmount: estimate.subtotalAmount,
        taxRate: estimate.taxRate,
        taxAmount: estimate.taxAmount,
        discountAmount: estimate.discountAmount,
        totalAmount: estimate.totalAmount,
        items: {
          create: estimate.items.map((it) => ({
            name: it.name,
            type: it.type,
            quantity: it.quantity,
            unitPrice: it.unitPrice,
            lineTotal: it.lineTotal,
            organization: { connect: { id: DEFAULT_ORG_ID } },
            ...(it.productId ? { product: { connect: { id: it.productId } } } : {}),
          })),
        },
      },
      select: { id: true },
    })

    return NextResponse.json({ estimateId: created.id })
  } catch (err: any) {
    console.error(err)
    return NextResponse.json({ error: "Failed to duplicate estimate" }, { status: 500 })
  }
}
