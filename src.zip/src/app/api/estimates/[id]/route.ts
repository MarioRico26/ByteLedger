import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { DEFAULT_ORG_ID } from "@/lib/tenant"

type ProductType = "PRODUCT" | "SERVICE"

function asNumber(v: unknown, fallback = 0) {
  const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : NaN
  return Number.isFinite(n) ? n : fallback
}

function asType(v: unknown): ProductType {
  return v === "SERVICE" ? "SERVICE" : "PRODUCT"
}

export async function GET(_: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params

  const estimate = await prisma.estimate.findFirst({
    where: { id, organizationId: DEFAULT_ORG_ID },
    include: {
      customer: true,
      organization: true,
      items: { orderBy: { createdAt: "asc" }, include: { product: true } },
      sale: { select: { id: true } },
    },
  })

  if (!estimate) {
    return NextResponse.json({ error: "Estimate not found" }, { status: 404 })
  }

  return NextResponse.json({ estimate })
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params
    const body = await req.json()

    const existing = await prisma.estimate.findFirst({
      where: { id, organizationId: DEFAULT_ORG_ID },
      select: { id: true, saleId: true },
    })

    if (!existing) {
      return NextResponse.json({ error: "Estimate not found" }, { status: 404 })
    }

    if (existing.saleId) {
      return NextResponse.json({ error: "Estimate already converted. Editing is disabled." }, { status: 400 })
    }

    const title = String(body.title || "Estimate")
    const customerId = String(body.customerId || "")
    if (!customerId) {
      return NextResponse.json({ error: "customerId is required" }, { status: 400 })
    }

    const rawItems = Array.isArray(body.items) ? body.items : []
    if (rawItems.length === 0) {
      return NextResponse.json({ error: "At least one item is required" }, { status: 400 })
    }

    const items = rawItems.map((it: any) => {
      const quantity = Math.max(asNumber(it.quantity, 1), 0)
      const unitPrice = Math.max(asNumber(it.unitPrice, 0), 0)
      const lineTotal = Math.max(quantity * unitPrice, 0)

      const productId = it.productId ? String(it.productId) : null
      const name = String(it.name || "").trim() || "Item"

      return {
        productId,
        name,
        type: asType(it.type),
        quantity,
        unitPrice,
        lineTotal,
      }
    })

    const subtotal = items.reduce((sum, it) => sum + it.lineTotal, 0)

    const taxRateNum = Math.max(asNumber(body.taxRate, 0), 0)
    const taxAmount = taxRateNum > 0 ? subtotal * (taxRateNum / 100) : 0

    const discountAmountNum =
      body.discountAmount === null || body.discountAmount === undefined || body.discountAmount === ""
        ? 0
        : Math.max(asNumber(body.discountAmount, 0), 0)

    const total = Math.max(subtotal + taxAmount - discountAmountNum, 0)

    const updated = await prisma.estimate.update({
      where: { id },
      data: {
        title,
        customerId,
        status: body.status ? body.status : undefined,
        notes: body.notes === undefined ? undefined : body.notes ? String(body.notes) : null,
        subtotalAmount: subtotal,
        taxRate: taxRateNum,
        taxAmount,
        discountAmount: discountAmountNum,
        totalAmount: total,
        items: {
          deleteMany: {},
          create: items.map((it) => ({
            name: it.name,
            type: it.type,
            quantity: it.quantity,
            unitPrice: it.unitPrice,
            lineTotal: it.lineTotal,
            organization: { connect: { id: DEFAULT_ORG_ID } },
            ...(it.productId ? { product: { connect: { id: it.productId } } } : {}),
          })),
        },
      },
      include: {
        customer: true,
        organization: true,
        items: { orderBy: { createdAt: "asc" }, include: { product: true } },
      },
    })

    return NextResponse.json({ estimate: updated })
  } catch (err: any) {
    console.error(err)
    return NextResponse.json({ error: "Failed to update estimate" }, { status: 500 })
  }
}
