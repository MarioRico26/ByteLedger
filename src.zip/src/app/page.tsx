import Link from "next/link"
import { prisma } from "@/lib/prisma"
import { requireOrgId } from "@/lib/auth"

export const dynamic = "force-dynamic"

function toMoney(v: number) {
  if (!Number.isFinite(v)) return "$0.00"
  return v.toLocaleString(undefined, { style: "currency", currency: "USD" })
}

function fmtShortDate(d: Date) {
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" })
}

export default async function DashboardPage() {
  const orgId = await requireOrgId()
  const now = new Date()
  const last30 = new Date(now)
  last30.setDate(now.getDate() - 30)
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1)
  const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1)

  const [sales30, payments30, openBalances, overdueCount, recentSales, recentPayments, recentEmails] =
    await Promise.all([
      prisma.sale.aggregate({
        where: { organizationId: orgId, saleDate: { gte: last30 } },
        _sum: { totalAmount: true },
      }),
      prisma.payment.aggregate({
        where: { organizationId: orgId, paidAt: { gte: last30 } },
        _sum: { amount: true },
      }),
      prisma.sale.aggregate({
        where: { organizationId: orgId, balanceAmount: { gt: 0 } },
        _sum: { balanceAmount: true },
      }),
      prisma.sale.count({
        where: {
          organizationId: orgId,
          balanceAmount: { gt: 0 },
          dueDate: { lt: now },
        },
      }),
      prisma.sale.findMany({
        where: { organizationId: orgId },
        orderBy: { createdAt: "desc" },
        take: 5,
        select: {
          id: true,
          description: true,
          createdAt: true,
          totalAmount: true,
          customer: { select: { fullName: true } },
        },
      }),
      prisma.payment.findMany({
        where: { organizationId: orgId },
        orderBy: { paidAt: "desc" },
        take: 5,
        select: {
          id: true,
          amount: true,
          paidAt: true,
          method: true,
          sale: { select: { id: true, description: true } },
        },
      }),
      prisma.emailLog.findMany({
        where: { organizationId: orgId, saleId: { not: null } },
        orderBy: { createdAt: "desc" },
        take: 5,
        select: {
          id: true,
          createdAt: true,
          status: true,
          subject: true,
          sale: { select: { id: true, description: true } },
        },
      }),
    ])

  const activity = [
    ...recentSales.map((s) => ({
      id: `sale-${s.id}`,
      at: s.createdAt,
      title: "Invoice created",
      subtitle: `${s.description} • ${s.customer.fullName}`,
      amount: Number(s.totalAmount || 0),
    })),
    ...recentPayments.map((p) => ({
      id: `pay-${p.id}`,
      at: p.paidAt,
      title: "Payment received",
      subtitle: `${p.sale?.description || "Invoice"} • ${p.method}`,
      amount: Number(p.amount || 0),
    })),
    ...recentEmails.map((e) => ({
      id: `email-${e.id}`,
      at: e.createdAt,
      title: e.status === "FAILED" ? "Email failed" : "Email sent",
      subtitle: `${e.subject || "Invoice email"} • ${e.sale?.description || "Invoice"}`,
      amount: null,
    })),
  ]
    .sort((a, b) => b.at.getTime() - a.at.getTime())
    .slice(0, 8)

  const earliest = new Date(now.getFullYear(), now.getMonth() - 5, 1)
  const [salesForChart, paymentsForChart] = await Promise.all([
    prisma.sale.findMany({
      where: { organizationId: orgId, saleDate: { gte: earliest, lt: nextMonth } },
      select: { saleDate: true, createdAt: true, totalAmount: true },
    }),
    prisma.payment.findMany({
      where: { organizationId: orgId, paidAt: { gte: earliest, lt: nextMonth } },
      select: { paidAt: true, amount: true },
    }),
  ])

  const months: { label: string; key: string; start: Date }[] = []
  for (let i = 5; i >= 0; i -= 1) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
    const key = `${d.getFullYear()}-${d.getMonth()}`
    months.push({
      label: d.toLocaleDateString(undefined, { month: "short" }),
      key,
      start: d,
    })
  }

  const salesByMonth: Record<string, number> = {}
  const paymentsByMonth: Record<string, number> = {}

  for (const m of months) {
    salesByMonth[m.key] = 0
    paymentsByMonth[m.key] = 0
  }

  for (const s of salesForChart) {
    const d = s.saleDate || s.createdAt || now
    const key = `${d.getFullYear()}-${d.getMonth()}`
    if (key in salesByMonth) {
      salesByMonth[key] += Number(s.totalAmount || 0)
    }
  }
  for (const p of paymentsForChart) {
    const d = p.paidAt
    const key = `${d.getFullYear()}-${d.getMonth()}`
    if (key in paymentsByMonth) {
      paymentsByMonth[key] += Number(p.amount || 0)
    }
  }

  const chartRows = months.map((m) => ({
    label: m.label,
    sales: salesByMonth[m.key],
    payments: paymentsByMonth[m.key],
  }))
  const chartMax = Math.max(
    1,
    ...chartRows.map((r) => Math.max(r.sales, r.payments))
  )

  const upcoming = await prisma.sale.findMany({
    where: {
      organizationId: orgId,
      balanceAmount: { gt: 0 },
      dueDate: { gte: now, lt: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 15) },
    },
    orderBy: { dueDate: "asc" },
    take: 6,
    select: {
      id: true,
      description: true,
      dueDate: true,
      balanceAmount: true,
      customer: { select: { fullName: true } },
    },
  })

  const Card = ({ href, title, desc }: { href: string; title: string; desc: string }) => (
    <Link
      href={href}
      className="rounded-2xl border border-slate-200 bg-slate-50 p-5 transition hover:border-slate-300 hover:bg-white"
    >
      <div className="text-lg font-semibold text-slate-900">{title}</div>
      <div className="mt-1 text-sm text-slate-500">{desc}</div>
    </Link>
  )

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">Dashboard</h1>
          <div className="mt-1 text-sm text-slate-500">
            Snapshot of sales, payments, and cash position.
          </div>
        </div>
        <Link
          href="/reports"
          className="inline-flex items-center justify-center rounded-xl border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:border-slate-300 hover:text-slate-900"
        >
          Open Reports
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <div className="rounded-2xl border border-slate-200 bg-gradient-to-br from-white via-slate-50 to-white p-5">
          <div className="text-xs uppercase tracking-widest text-slate-400">Last 30 days</div>
          <div className="mt-2 text-2xl font-semibold text-slate-900">{toMoney(Number(sales30._sum.totalAmount || 0))}</div>
          <div className="mt-1 text-xs text-slate-500">Invoiced revenue</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="text-xs uppercase tracking-widest text-slate-400">Collected</div>
          <div className="mt-2 text-2xl font-semibold text-slate-900">{toMoney(Number(payments30._sum.amount || 0))}</div>
          <div className="mt-1 text-xs text-slate-500">Payments last 30 days</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="text-xs uppercase tracking-widest text-slate-400">Outstanding</div>
          <div className="mt-2 text-2xl font-semibold text-slate-900">{toMoney(Number(openBalances._sum.balanceAmount || 0))}</div>
          <div className="mt-1 text-xs text-slate-500">Open balances</div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="text-xs uppercase tracking-widest text-slate-400">Overdue</div>
          <div className="mt-2 text-2xl font-semibold text-slate-900">{overdueCount}</div>
          <div className="mt-1 text-xs text-slate-500">Past due invoices</div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold text-slate-900">Revenue vs Payments</div>
              <div className="text-xs text-slate-500">Last 6 months</div>
            </div>
            <div className="text-xs text-slate-500">Updated {fmtShortDate(now)}</div>
          </div>

          <div className="mt-6 grid grid-cols-6 gap-3">
            {chartRows.map((row) => {
              const salesPct = Math.round((row.sales / chartMax) * 100)
              const payPct = Math.round((row.payments / chartMax) * 100)
              return (
                <div key={row.label} className="flex flex-col items-center gap-2">
                  <div className="flex h-32 w-full items-end gap-1">
                    <div
                      className="w-1/2 rounded-lg bg-emerald-400/80"
                      style={{ height: `${Math.max(6, salesPct)}%` }}
                    />
                    <div
                      className="w-1/2 rounded-lg bg-sky-400/80"
                      style={{ height: `${Math.max(6, payPct)}%` }}
                    />
                  </div>
                  <div className="text-xs text-slate-500">{row.label}</div>
                </div>
              )
            })}
          </div>

          <div className="mt-4 flex items-center gap-4 text-xs text-slate-500">
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-emerald-400/80" /> Invoiced
            </div>
            <div className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-sky-400/80" /> Payments
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="text-sm font-semibold text-slate-900">Upcoming due</div>
          <div className="mt-1 text-xs text-slate-500">Next 14 days</div>
          <div className="mt-4 space-y-3">
            {upcoming.length === 0 ? (
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-500">
                No invoices due soon.
              </div>
            ) : (
              upcoming.map((item) => (
                <div key={item.id} className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                  <div className="text-sm font-semibold text-slate-900">{item.description}</div>
                  <div className="mt-1 flex items-center justify-between text-xs text-slate-500">
                    <span>{item.customer.fullName}</span>
                    <span>Due {item.dueDate ? fmtShortDate(item.dueDate) : "—"}</span>
                  </div>
                  <div className="mt-2 text-sm font-semibold text-rose-600">
                    {toMoney(Number(item.balanceAmount || 0))}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="text-sm font-semibold text-slate-900">Recent activity</div>
          <div className="mt-1 text-xs text-slate-500">Latest movements in your account</div>
          <div className="mt-4 space-y-3">
            {activity.length === 0 ? (
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 text-sm text-slate-500">
                No activity yet.
              </div>
            ) : (
              activity.map((a) => (
                <div key={a.id} className="flex items-center justify-between gap-4 rounded-xl border border-slate-200 bg-slate-50 p-3">
                  <div>
                    <div className="text-sm font-semibold text-slate-900">{a.title}</div>
                    <div className="text-xs text-slate-500">{a.subtitle}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-slate-500">{fmtShortDate(a.at)}</div>
                    {a.amount !== null ? (
                      <div className="text-sm font-semibold text-slate-900">{toMoney(a.amount)}</div>
                    ) : null}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-5">
          <div className="text-sm font-semibold text-slate-900">Quick access</div>
          <div className="mt-1 text-xs text-slate-500">Go straight to a module</div>
          <div className="mt-4 grid gap-3 md:grid-cols-2">
            <Card href="/customers" title="Customers" desc="Manage customer profiles." />
            <Card href="/products" title="Catalog" desc="Products & services pricing." />
            <Card href="/estimates" title="Estimates" desc="Create quotes and send to clients." />
            <Card href="/sales" title="Sales" desc="Invoices and payments tracking." />
            <Card href="/payments" title="Payments" desc="Log and reconcile payments." />
            <Card href="/settings/organization" title="Settings" desc="Organization profile." />
          </div>
        </div>
      </div>
    </div>
  )
}
