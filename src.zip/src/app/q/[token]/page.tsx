import { prisma } from "@/lib/prisma"
import QuoteDoc from "@/app/estimates/ui/QuoteDoc"

export const dynamic = "force-dynamic"

export default async function PublicQuotePage(props: { params: Promise<{ token: string }> }) {
  const { token } = await props.params

  const estimate = await prisma.estimate.findFirst({
    where: { quoteToken: token },
    include: {
      organization: true,
      customer: true,
      items: { orderBy: { createdAt: "asc" } },
      sale: { select: { id: true } },
    },
  })

  if (!estimate) {
    return (
      <div className="min-h-screen bg-zinc-950 px-6 py-10">
        <div className="mx-auto max-w-2xl rounded-2xl border border-zinc-800 bg-zinc-950/40 p-5 text-sm text-zinc-400">
          Quote not found.
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-zinc-950 px-6 py-10">
      <div className="mx-auto max-w-4xl space-y-4">
        <div className="flex flex-wrap items-center gap-2 print:hidden">
          <button
            onClick={() => window.print()}
            className="rounded-xl bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-500"
          >
            Print / Save PDF
          </button>

          {estimate.saleId ? (
            <a
              href={`/sales/${estimate.saleId}`}
              className="rounded-xl border border-zinc-800 bg-zinc-950/40 px-3 py-2 text-sm font-medium text-zinc-100 hover:bg-zinc-900/40"
            >
              Open sale
            </a>
          ) : null}

          <div className="ml-auto text-xs text-zinc-500">
            Status: <span className="text-zinc-300">{estimate.status}</span>
          </div>
        </div>

        <div className="overflow-hidden rounded-2xl border border-zinc-800 bg-white">
          <QuoteDoc estimate={estimate as any} organization={estimate.organization as any} customer={estimate.customer as any} items={estimate.items as any} />
        </div>
      </div>
    </div>
  )
}
